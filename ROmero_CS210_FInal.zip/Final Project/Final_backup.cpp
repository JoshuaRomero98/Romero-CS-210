//Joshua Romero CS210 Final Project

#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;


class frequency {
public:
	void option1(map <string, int>& frequencyMap) {
		cout << "You chose option 1" << endl;
		cout << "Please enter word or item to find" << endl;
		string word;
		cin >> word;
		int freq = frequencyMap[word];
		cout << "the frequency of " << word << " is: " << freq << endl;


	}
	void option2(map <string, int>& frequencyMap) {
		cout << "you chose option 2" << endl;
		cout << "here is the frequency of all the words in the list" << endl;
		for (const auto& pair : frequencyMap) {
			cout << pair.first << " : " << pair.second << endl;
		}

	}
	void option3() {
		cout << "you chose option 3" << endl;
		cout << "here is your histogram" << endl;
		for (const auto& pair : frequencyMap) {
			cout << pair.first << " ";
			for (int i = 0; i < pair.second; i++) {
				cout << "*";
			}
			cout << endl;
		}

	}
	void option4() {
		cout << "you chose option 4" << endl;
	}
	void main_menu() {
		cout << " Welcome Corner Grocer!! " << endl;
		cout << "Please select an option from the menu - 1-4" << endl;
		cout << "Option 1- Input a word and you will get the frequency" << endl;
		cout << "Option 2 - Outputs a list of words and their frequencies" << endl;
		cout << "Option 3 - Histograph represenation of the frequency of words" << endl;
		cout << "Option 4 - Exit " << endl;

		int choice;
		bool input = false;

		while (!input) {
			cout << "Please type the number of your selection" << endl;
			cin >> choice;

			//input validation
			if (cin.fail() || choice < 1 || choice > 4) {
				cout << "Invalid Input - Please input a number 1-4" << endl;
				cin.clear();
				cin.ignore(100, '\n');
			}
			else {
				input = true;
			}
		}
		//switch case to intiate different functions based on options
		switch (choice) {
		case 1:
			option1(frequencyMap);
			break;
		case 2:
			option2(frequencyMap);
			break;
		case 3:
			option3();
			break;
		case 4:
			cout << "Exiting Menu" << endl;
			break;
		default:
			cout << "invalid input but from switch statement" << endl;
			break;
		}

	}
	//function to modify the map based on the inputted fule 
	void mapChanger(string filename) {
		ifstream infile(filename);
		if (!infile) {
			cout << "Couldnt open that file" << endl;
		}
		while (infile >> counter) {
			frequencyMap[counter]++;
		}

		//output file per specification

		ofstream outputFile("output.txt");
		for (const auto& pair : frequencyMap) {
			outputFile << pair.first << " : " << pair.second << endl;
		}
		outputFile.close();
		infile.close();

	}

private:
	//map and counter
	map <string, int> frequencyMap;
	string counter;
};


int main() {
	//creates new object of type frequency
	frequency cornerGrocer;
	cornerGrocer.mapChanger("input.txt");
	cornerGrocer.main_menu();
}